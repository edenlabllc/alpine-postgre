/* pgaudit/pgaudit--1.0--1.1.1.sql */

-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION pgaudit" to load this file.\quit

-- nothing to do, this corrects the initially incorrect version for 9.6
